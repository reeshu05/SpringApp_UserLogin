package com.userlogin.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.userlogin.entity.User;
import com.userlogin.repository.UserLoginRepository;

@Service
public class UserLoginImpl {
	
	@Autowired
	UserLoginRepository userLoginRepo;
	
	public boolean isCredentialMatch(User user) {
		
		 Optional<User> userOptional = userLoginRepo.findById(user.getLoginId());
		 
		 if(userOptional.isPresent()) {
			 User userData = userOptional.get(); 
			 if(user.getPassword().equals(userData.getPassword())) {
				 return true;
			 }else {
				 return false;
			 }
		 }else {
			 return false;
		 }
		 
		
	}

}
