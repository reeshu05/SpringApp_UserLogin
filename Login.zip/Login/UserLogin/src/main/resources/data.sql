insert into user
(login_id,email_id,password)
values
(1,'test@gmail.com','test');