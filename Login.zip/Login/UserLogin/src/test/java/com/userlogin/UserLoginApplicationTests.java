package com.userlogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
